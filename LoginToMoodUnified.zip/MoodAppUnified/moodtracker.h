#ifndef MOODTRACKER_H
#define MOODTRACKER_H

#include <QMainWindow>

namespace Ui {
class MoodTracker;
}

class MoodTracker : public QMainWindow
{
    Q_OBJECT

public:
    explicit MoodTracker(QWidget *parent = nullptr);
    ~MoodTracker();

private:
    Ui::MoodTracker *ui;
};

#endif // MOODTRACKER_H
