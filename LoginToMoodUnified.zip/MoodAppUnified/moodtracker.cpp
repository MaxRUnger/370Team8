#include "moodtracker.h"
#include "ui_moodtracker.h"

MoodTracker::MoodTracker(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MoodTracker)
{
    ui->setupUi(this);
}

MoodTracker::~MoodTracker()
{
    delete ui;
}
