
#include <QApplication>
#include "LoginPage.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    LoginPage loginPage;
    loginPage.show();

    return app.exec();
}
