#include "LoginPage.h"
#include "ui_LoginPage.h"
#include "UserManager.h"

LoginPage::LoginPage(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::LoginPage)
{
    ui->setupUi(this);

    connect(ui->loginButton, &QPushButton::clicked, this, &LoginPage::handleLogin);
    connect(ui->signupButton, &QPushButton::clicked, this, &LoginPage::handleSignup);
}

LoginPage::~LoginPage()
{
    delete ui;
}

void LoginPage::handleLogin()
{
    QString username = ui->usernameEdit->text();
    QString password = ui->passwordEdit->text();

    if (UserManager::instance().validateUser(username, password)) {
        moodTrackerWindow = new MoodTracker();
        moodTrackerWindow->show();
        this->close();
    } else {
        ui->statusLabel->setText("Invalid username or password.");
    }
}

void LoginPage::handleSignup()
{
    QString username = ui->usernameEdit->text();
    QString password = ui->passwordEdit->text();

    if (UserManager::instance().addUser(username, password)) {
        ui->statusLabel->setText("Signup successful. You can now log in.");
    } else {
        ui->statusLabel->setText("Username already exists.");
    }
}
