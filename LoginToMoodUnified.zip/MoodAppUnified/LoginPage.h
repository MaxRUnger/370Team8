#ifndef LOGINPAGE_H
#define LOGINPAGE_H

#include <QMainWindow>
#include "moodtracker.h"

namespace Ui {
class LoginPage;
}

class LoginPage : public QMainWindow
{
    Q_OBJECT

public:
    explicit LoginPage(QWidget *parent = nullptr);
    ~LoginPage();

private slots:
    void handleLogin();
    void handleSignup();

private:
    Ui::LoginPage *ui;
    MoodTracker *moodTrackerWindow;
};

#endif // LOGINPAGE_H
